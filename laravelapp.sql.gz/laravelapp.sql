-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 11, 2021 at 03:22 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laravelapp`
--

-- --------------------------------------------------------

--
-- Table structure for table `downloads`
--

CREATE TABLE `downloads` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `sku` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `stock_id` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `forms`
--

CREATE TABLE `forms` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2014_10_12_200000_add_two_factor_columns_to_users_table', 1),
(4, '2019_08_19_000000_create_failed_jobs_table', 1),
(5, '2021_06_12_141452_add_address_to_users_table', 2),
(6, '2021_06_12_181249_add_address_to_users', 3),
(7, '2021_06_13_114537_create_forms_table', 4),
(8, '2021_10_08_105616_create_stocks', 5),
(9, '2021_10_10_204202_downloads', 6);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `stocks`
--

CREATE TABLE `stocks` (
  `stock_id` bigint(20) UNSIGNED NOT NULL,
  `varient` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `stock_num` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `two_factor_secret` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `two_factor_recovery_codes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `address`, `email_verified_at`, `password`, `two_factor_secret`, `two_factor_recovery_codes`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'test', '123@gmail.com', '', NULL, '$2y$10$Uo3CLbSMVYVCbKiVTd/.x.aqljfyFXS.hwAv2nNUYFeDS5MuSTIVe', NULL, NULL, NULL, '2021-03-06 16:30:50', '2021-03-06 16:30:50'),
(2, 'Kamal', 'kk@gmail.com', '', NULL, '$2y$10$98059gI5qNP8DOc.fxzm5OIBoULNydDEQ.2ibQsyGNdEDJa/PUoEi', NULL, NULL, NULL, '2021-03-07 05:53:54', '2021-03-07 05:53:54'),
(3, 'Hassan Naeem', '3434@gmail.com', '', '2021-09-05 06:07:49', '$2y$10$xUNlhLyEr0WF/2xp/FJOVuw6bN2jQ5pFEEOM0WZ9WddvSXKGieqYi', NULL, NULL, 'GpP2sBaSwAuPj5L4s4kTLltpeYkFWMkP2HSrS5cw451LUAA7IiNaC2ysvbkm', '2021-04-02 04:45:15', '2021-09-05 06:07:49'),
(4, 'TAyyab', 'tayyab.naeem00786@gmail.com', '', NULL, '$2y$10$lCgxnCV4X4V4KaFTmH40pOTo30bEDjSC55xpViov4QQRsDfv2b2he', NULL, NULL, NULL, '2021-06-12 13:01:10', '2021-06-12 13:01:10'),
(5, 'kala', 'kk@gmail', 'rts', NULL, '$2y$10$ugOolzp4V.Q0mSympST63uqaShjQv9gEB2d2AfSz4f6gvufDVnlzO', NULL, NULL, NULL, '2021-06-12 13:33:46', '2021-06-12 13:33:46'),
(6, 'New User', 'hassanjogi92@gmail.com', 'Gujranwala', NULL, '$2y$10$akYKSvqwO2jHFucEAZiHl..uTWqlTvQs.ChcGdYyr5iM0sTEonxZW', NULL, NULL, NULL, '2021-09-01 04:00:31', '2021-09-01 04:00:31'),
(7, 'jamched', '3232@gmail.conm', '333', NULL, '$2y$10$XX4cSVcAEeEaFuiAdQBSCuVa4IRQHE6oAFd1UbFd3.tE7WbHRBqGW', NULL, NULL, NULL, '2021-09-01 04:14:02', '2021-09-01 04:14:02'),
(8, 'jamched', 'jimi@gmail.com', '333', NULL, '$2y$10$9TpphjiqaTKX19AZK23WEOPeGWt1AdMIJvDfbN5mF0lGj0oR2mEMK', NULL, NULL, NULL, '2021-09-01 04:14:34', '2021-09-01 04:14:34'),
(9, 'Hassan Naeem', 'hassannaeem0078600@gmail.com', 'Street # 7 Moh. Sultan GT Road Gujrat', NULL, '$2y$10$snqmfQ14WGLZPCGXAuXSk.NbxGzdjGg6KvrQHtdkycLj7bIHy.VBG', NULL, NULL, NULL, '2021-09-01 06:02:43', '2021-09-01 06:02:43'),
(10, 'Ali', 'hassan007.1901351@gmail.com', 'street # 7 GT Road Gujrat, street # 7 GT Road Gujrat', '2021-09-05 10:01:40', '$2y$10$8LpzAsrjpR1Jv6FeHYd8AeO2WwdxiFgeLUU2onQ7vL4FP4p.KqXf6', NULL, NULL, NULL, '2021-09-05 09:50:05', '2021-09-05 10:01:40'),
(11, 'hassan ali', '2323@gmail.com', 'lahore', NULL, '$2y$10$6PqBlBkxm6v1ivimWWeT4OQHWLVav6ZJKQWxIzQmxkTZ6cbtdyaXy', NULL, NULL, NULL, '2021-10-08 00:07:53', '2021-10-08 00:07:53'),
(12, 'Ali', 'ali.ali@gmail.com', 'Gujrat', NULL, '$2y$10$LOTOW7liKq2685sCRl1JC.AFZVUwGxfEDKy56.P3sxgnl0xmQpEBe', NULL, NULL, NULL, '2021-10-08 00:21:33', '2021-10-08 00:21:33');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `downloads`
--
ALTER TABLE `downloads`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `forms`
--
ALTER TABLE `forms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `stocks`
--
ALTER TABLE `stocks`
  ADD PRIMARY KEY (`stock_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `downloads`
--
ALTER TABLE `downloads`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `forms`
--
ALTER TABLE `forms`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `stocks`
--
ALTER TABLE `stocks`
  MODIFY `stock_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=79;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
